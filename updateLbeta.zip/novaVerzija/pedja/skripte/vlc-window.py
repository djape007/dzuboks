def inplace_change(filename, old_string, new_string):
    # Safely read the input filename using 'with'
    with open(filename) as f:
        s = f.read()
        if (old_string not in s) or (new_string in s):
            #print '"{old_string}" not found in {filename}.'.format(**locals())
            return

    # Safely write the changed content, if found in the file
    with open(filename, 'w') as f:
        #print 'Changing "{old_string}" to "{new_string}" in {filename}'.format(**locals())
        s = s.replace(old_string, new_string)
        f.write(s)

oldstr = "</applications>"
newstr = """    <application role="vlc-video" name="vlc" class="Vlc">
        <focus>no</focus>
    </application>
  </applications>"""

inplace_change("/home/jukebox/.config/openbox/lubuntu-rc.xml", oldstr, newstr)