class PomocneMetode:
	
	def __init__(self):
		self.dostupniZanroviVecUpisani = []

	def UcitajBanovanePevace(self,fajl):
		f = open(fajl)
		banovani = []

		for red in f:
			red = str(red)
			red = red.strip()
			if len(red) > 0:
				banovani.append(red)

		f.close()
		return banovani

	#svaki red dodaje u listu i vraca je. U jednom redu treba da je jedan zanr za skidanje
	def ZanroviZaPreuzimanje(self,fajl):
		f = open(fajl)

		vratiti = []
		for red in f:
			red = str(red)
			red = red.strip()
			if len(red) > 0:
				vratiti.append(red)

		f.close()
		return vratiti

	def PostaviKategorijuABC(self, pevac):
		tmpPevac = pevac
		kategorija = ""

		if(tmpPevac[0] == 'A' or tmpPevac[0] == 'B' or tmpPevac[0] == 'C'):
			kategorija = "A-B-C"
		elif (tmpPevac[0] == 'D' or tmpPevac[0] == 'E' or tmpPevac[0] == 'F'):
			kategorija = "D-E-F"
		elif (tmpPevac[0] == 'G' or tmpPevac[0] == 'H' or tmpPevac[0] == 'I'):
			kategorija = "G-H-I"
		elif (tmpPevac[0] == 'J' or tmpPevac[0] == 'K' or tmpPevac[0] == 'L'):
			kategorija = "J-K-L"
		elif (tmpPevac[0] == 'M' or tmpPevac[0] == 'N' or tmpPevac[0] == 'O'):
			kategorija = "M-N-O"
		elif (tmpPevac[0] == 'P' or tmpPevac[0] == 'R' or tmpPevac[0] == 'S'):
			kategorija = "P-R-S"
		elif (tmpPevac[0] == 'T' or tmpPevac[0] == 'U' or tmpPevac[0] == 'V'):
			kategorija = "T-U-V"
		elif (tmpPevac[0] == 'X' or tmpPevac[0] == 'Y' or tmpPevac[0] == 'Z'):
			kategorija = "X-Y-Z"
	
		return kategorija

	def DodajZanrUDostupne(self, zanr, putanjaDoFajla):
		if not (zanr in self.dostupniZanroviVecUpisani):
			self.dostupniZanroviVecUpisani.append(zanr)
			fajl = open(putanjaDoFajla, "a")
			fajl.write(zanr + "\n")
			fajl.close()
