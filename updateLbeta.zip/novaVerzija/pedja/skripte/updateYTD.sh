#!/bin/bash

echo '1233' | sudo -S -H pip install --upgrade youtube-dl

exit 0