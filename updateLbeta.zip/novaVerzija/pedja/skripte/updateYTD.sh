#!/bin/bash

echo '1233' | sudo -S apt-get install python-setuptools
echo '1233' | sudo -S easy_install pip
echo '1233' | sudo -S -H pip install --upgrade youtube-dl

exit 0