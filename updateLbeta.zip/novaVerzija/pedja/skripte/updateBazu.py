import urllib2
import os
from pomocnaUpdateBazu import PomocneMetode	

def ObrisiFajlGdeSeNalazeSviZanrovi(putanja):
	try:
		os.remove(putanja)
	except:
		print("Ne postoji fajl sa svim zanrovima!")

def UpisiLinkPesmeUFajl(b, zanr, pevac, pesma, linkPesme, putanjaDoMuzike):
	if '90' in zanr:
		zanr = "Pesme 90-ih"

	if not(zanr in preuzmiZanroveList):
		return

	if not os.path.exists(putanjaDoMuzike + zanr):
		os.makedirs(putanjaDoMuzike + zanr)

	tmpPevac = pevac.upper()
	
	kategorija = b.PostaviKategorijuABC(tmpPevac)

	if not os.path.exists(putanjaDoMuzike + zanr + "/" + kategorija):
		os.makedirs(putanjaDoMuzike + zanr + "/" + kategorija)

	if not os.path.exists(putanjaDoMuzike + zanr + "/" + kategorija + "/" + pevac):
		os.makedirs(putanjaDoMuzike + zanr + "/" + kategorija + "/" + pevac)

	if not "NIJE" in linkPesme:
		fajlLink = open(putanjaDoMuzike + zanr + "/" + kategorija + "/" + pevac + "/" + pesma + ".txt", "w")
		fajlLink.write(linkPesme)
		fajlLink.close()

def PreuzmiPesmeIzBaze(b, linkDoBaze, putanjaDoMuzike, putanjaDostupniZanrovi):
	fajlBaza = urllib2.urlopen(linkDoBaze)
	
	for red in fajlBaza:
		red2 = str(red.rstrip())
		#red2 = red2[2:len(red2)]
				
		zanr = red2[0:red2.index(']')]
		pevac = red2[red2.index(']') + 1:red2.index('}')]
		pesma = red2[(red2.index('}') + 1): red2.index('=')]
		link = red2[(red2.index('=') + 1): ]

		if pevac in banPevaci:
			continue

		if '~' in zanr:
			zanr1 = zanr[:zanr.index('~')]
			zanr2 = zanr[zanr.index('~') + 1:]

			if '90' in zanr1:
				zanr1 = "Pesme 90-ih"
			if '90' in zanr2:
				zanr2 = "Pesme 90-ih"

			b.DodajZanrUDostupne(zanr1, putanjaDostupniZanrovi)
			b.DodajZanrUDostupne(zanr2, putanjaDostupniZanrovi)

			UpisiLinkPesmeUFajl(b, zanr1, pevac, pesma, link, putanjaDoMuzike)
			UpisiLinkPesmeUFajl(b, zanr2, pevac, pesma, link, putanjaDoMuzike)
		else:
			if '90' in zanr:
				zanr = "Pesme 90-ih"

			b.DodajZanrUDostupne(zanr, putanjaDostupniZanrovi)

			UpisiLinkPesmeUFajl(b, zanr, pevac, pesma, link, putanjaDoMuzike)
	
	fajlBaza.close()

putanjaOsnovnaMuzika = "/home/jukebox/pedja/data/muzika/"
putanjaDoBanPevaca = "/home/jukebox/pedja/banPevaci.txt"
putanjaDoZanrZaDownload = "/home/jukebox/pedja/skiniZanrove.txt"
putanjaDostupniZanroviUBazi = "/home/jukebox/pedja/sviZanrovi.txt"

linkBaza1 = "https://raw.githubusercontent.com/djape007/predragBabicJukeB/master/bazaPesama1.txt"
linkBaza2 = "https://raw.githubusercontent.com/djape007/predragBabicJukeB/master/bazaPesama2.txt"

#KAO MAIN, KRECE IZVRSAVANJE

b = PomocneMetode()

banPevaci = b.UcitajBanovanePevace(putanjaDoBanPevaca)
preuzmiZanroveList = b.ZanroviZaPreuzimanje(putanjaDoZanrZaDownload)

print("Skinucu zanrove:")
print(preuzmiZanroveList)

#brise fajl u kom se nalaze svi dostupni zanrovi (jer ce apendovati u fajl)
ObrisiFajlGdeSeNalazeSviZanrovi(putanjaDostupniZanroviUBazi)

PreuzmiPesmeIzBaze(b, linkBaza1, putanjaOsnovnaMuzika, putanjaDostupniZanroviUBazi)
PreuzmiPesmeIzBaze(b, linkBaza2, putanjaOsnovnaMuzika, putanjaDostupniZanroviUBazi)

print("Gotovo updateovanje, mozes ugasiti ovo ")
