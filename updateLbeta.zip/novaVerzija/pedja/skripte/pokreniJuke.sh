#!/bin/bash

cd /home/jukebox/pedja/skripte

echo '1233' | sudo -S chmod 0777 /home/jukebox/.config/openbox/lubuntu-rc.xml

python vlc-window.py
openbox --reconfigure
./ytLuaAutoDownl.sh &

echo ""
echo ""
echo ""

python /home/jukebox/pedja/skripte/update_main.py

echo ""
echo ""
echo ""

./pokreniUnity.sh

exit 0
