import urllib2 as url2
import shutil
import os

#da bi skripta radila prvo u terminalu mora da se ukuca
#sudo chmod 777 /usr/lib/vlc/lua/playlist
def preuzmiNoviLua():
	linkDoLua = "https://raw.githubusercontent.com/videolan/vlc/master/share/lua/playlist/youtube.lua"
	
	try:
		ytLua = url2.urlopen(linkDoLua)
		tekst = ytLua.read();
	except:
		print("greska 111 skini_ytlua.py")
		return 0

	print("Gotovo preuzmianje ytlue")

	with open('youtube.lua', "w") as izlaz:
		izlaz.write(tekst)

	print("zapisano u fajl")

	try:
		os.remove('/usr/lib/vlc/lua/playlist/youtube.lua')
	except OSError as e:
		print("Greska prilikom brisanja starog lua: " + str(e))
	try:
		shutil.move('youtube.lua', '/usr/lib/vlc/lua/playlist/youtube.lua')
		print("Nova lua premestena na vlc lokaciju!")
		os.chmod('/usr/lib/vlc/lua/playlist/youtube.lua', 0777)
	except IOError as e:
		print('Greska:' + str(e))
	
	return 0

preuzmiNoviLua()
