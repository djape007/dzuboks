#!/bin/bash

cd /home/jukebox/pedja/skripte

./ytLuaAutoDownl.sh &

sleep 0.5

#lxterminal --command "python /home/jukebox/pedja/skripte/update_main.py"

python /home/jukebox/pedja/skripte/update_main.py

./pokreniUnity.sh &

exit 0
