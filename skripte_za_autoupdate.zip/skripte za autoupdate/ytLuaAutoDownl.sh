#!/bin/bash

echo '1233' | sudo -S chmod 777 /usr/lib/vlc/lua/playlist

sleep 0.5

python skini_ytlua.py

sleep 0.5

echo '1233' | sudo -S chmod 777 /usr/lib/vlc/lua/playlist/youtube.lua

echo 'gotovo updateovanje lue, chmod postavljen'

exit 0
