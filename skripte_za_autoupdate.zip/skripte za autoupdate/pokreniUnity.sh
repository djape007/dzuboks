#!/bin/bash

cvlc --no-video --play-and-exit vlc://quit

sleep 1

cd /home/jukebox/pedja/skripte

./pingGoogle.sh &

cd /home/jukebox/pedja/skripte

chmod +x pokreniServer.sh

./pokreniServer.sh &

sleep 3

cd /home/jukebox/pedja

chmod +x jukeB.x86

./jukeB.x86 &

exit 0
