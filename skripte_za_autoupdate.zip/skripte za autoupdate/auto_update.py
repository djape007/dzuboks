import urllib2 as url2
import zipfile as zf
import os
import shutil
import sys
from Tkinter import *
from time import sleep

def PreuzmiRaspakuj(nazivZipa, link, gdeEkstarktovati, obrisiOrigZip, rut, var):
	try:
		shutil.rmtree(gdeEkstarktovati + 'novaVerzija/')
	except Exception as e:
		print("Greska: " + str(e))	

	try:	
		var.set("Preuzimam fajlove...")
		rut.update_idletasks()
		fajl = url2.urlopen(link)
		#print("Preuzimanje zavrseno!")
		var.set(var.get() + "\nGotovo preuzimanje")
		rut.update_idletasks()
		sleep(1)
	except url2.HTTPError:
		#print("GRESKA: URL adresa nije ispravna")
		var.set(var.get() + "\nGreska: URL adresa neispravna")
		rut.update_idletasks()
		sleep(2.5)
		return
	
	with open(nazivZipa, 'wb') as output:
		output.write(fajl.read())
	#print("Prebacivanje u zip zavrseno!")
	var.set(var.get() + "\nArhiva sacuvana")
	rut.update_idletasks()
	sleep(1)
	with zf.ZipFile(nazivZipa, "r") as z:
		z.extractall(gdeEkstarktovati)
	#print("Raspakovao sam zip, lokacija: " + gdeEkstarktovati)
	var.set(var.get() + "\nArhiva raspakovana")
	rut.update_idletasks()
	sleep(1)	

	if obrisiOrigZip:
		os.remove(nazivZipa)
		print("Obrisan original zip!")

#kopira stari konfig, a taj sto je ostao, taj ce biti izmenjen
def KopirajStariConfig(gde, odakle):
	try:
		shutil.copy(odakle + 'parametriJuke.txt', gde + 'parametriJuke.txt')
		print("Kopirao sam stari config")
	except IOError as e:
		print("GRESKA 123: " + str(e))

#kao backup
def KopirajStareFajlove(gde, odakle):
	try:
		shutil.rmtree(gde)
	except Exception as e:
		print("Greska 120: " + str(e))

	try:
    		os.makedirs(gde)
	except Exception as e:
		print("Greska 121: " + str(e))

	try:
		shutil.move(odakle + 'jukeB_Data',gde + 'jukeB_Data')
		shutil.move(odakle + 'jukeB.x86', gde + 'jukeB.x86')
		print("Gotovo kopiranje stare verzije JB programa, nova lokacija: " + gde)
	except IOError as e:
		print("GRESKA 122: " + str(e))

def ucitajKonfig(lokacija):
	params = []
	konf = open(lokacija, "r")
	for red in konf:
		red = str(red)
		red = red.rstrip()
		red = red.lstrip()
		if red[0] == '#':
			continue
		params.append(red)
	konf.close()
	return params

def razvrstajParamObrDod(parametri):
	obr = []
	dod = []
	
	for item in parametri:
		item = str(item)
		if (item[0] == '-' and item[1] == '-'):
			obr.append(item[2:])
		elif (item[0] == '+' and item[1] == '+'):
			dod.append(item[2:])
	
	return [obr, dod]

def obrisiSkriptu(nazivSkripte):
	try:
		os.remove(nazivSkripte)
	except Exception as e:
		print("Greska: " + str(e))

def preimSkripti(staroIme, novoIme, putanja):
	try:
		shutil.move(putanja + staroIme, putanja + novoIme)
		os.chmod(putanja + novoIme, 0777)
	except Exception as e:
		print("Greska: " + str(e))

def obradiSkriptModif(putDoModif, putDoSkriptiNaKompu):
	fIN = open(putDoModif, "r")
	for red in fIN:
		red = str(red)
		red = red.lstrip()
		red = red.rstrip()

		if red[0] == '&' and red[1] == '&':
			oldName = red[2:red.index('&>')]
			newName = red[red.index('&>') + 2:]
			preimSkripti(oldName, newName, putDoSkriptiNaKompu)
		elif red[0] == '-' and red[1] == '-':
			delName = red[2:]
			obrisiSkriptu(putDoSkriptiNaKompu + delName)
	fIN.close()

def kopirajSkripte():
	novaVerPut = '/home/jukebox/novaVerzija/pedja/skripte/'
	lokacijaSkripti = '/home/jukebox/pedja/skripte/'
	for fajl in os.listdir(novaVerPut):
		if fajl[len(fajl)-4:] == '.txt':
			continue
		try:
			shutil.move(novaVerPut + str(fajl), lokacijaSkripti + str(fajl))
			os.chmod(lokacijaSkripti + str(fajl) , 0777)
		except Exception as e:
			print("Greska 13: " + str(e))
def main(rut, var):
	putSkripte = '/home/jukebox/pedja/skripte/'
	basePath = '/home/jukebox/'
	nazivZipFajla = basePath + 'upd.zip'
	linkDoZipa = 'https://github.com/djape007/predragBabicJukeB/raw/master/updateL.zip'
	gdeEkstarktovati = '/home/jukebox/'

	lokNoviKonfig = '/home/jukebox/novaVerzija/parametriJuke.txt'
	lokStariKonfig = '/home/jukebox/parametriJuke.txt'

	newParamsDel = []
	newParamsAdd= []
	oldParams = []
	noviKonfig = []
	
	PreuzmiRaspakuj(nazivZipFajla, linkDoZipa, gdeEkstarktovati, True, rut, var)
	KopirajStareFajlove(basePath + 'staraVerzija/', basePath + 'pedja/')
	KopirajStariConfig(basePath + 'staraVerzija/', basePath)

	###DEO1 --- namestanje konfig fajla
	newParamsDel, newParamsAdd = razvrstajParamObrDod(ucitajKonfig(lokNoviKonfig))
	oldParams = ucitajKonfig(lokStariKonfig)

	for item in oldParams:
		if item[:item.index('=')] in newParamsDel:
			continue
		noviKonfig.append(item)

	noviKonfig = noviKonfig + newParamsAdd
	noviKonfig = list(set(noviKonfig))
	noviKonfigFajl = open(lokStariKonfig, "w")

	for item in noviKonfig:
		noviKonfigFajl.write(item + '\n')

	noviKonfigFajl.close()
	###DEO1 --- kraj

	###DEO2 --- kopiranje novog unitija
	try:
		shutil.move(basePath + 'novaVerzija/pedja/jukeB_Data',basePath + 'pedja/jukeB_Data')
	except Exception as e:
		print("Greska 511: " + str(e))
	try:
		shutil.move(basePath + 'novaVerzija/pedja/jukeB.x86',basePath + 'pedja/jukeB.x86')
	except Exception as e:
		print("Greska 512: " + str(e))
	###DEO2 --- kraj
	###DEO3 - kopira/brise/preimenuje skripte
	obradiSkriptModif(basePath + 'novaVerzija/pedja/skripte/modifikacije.txt', basePath + 'pedja/skripte/')
	kopirajSkripte()
	###DEO3 --- kraj

	###DEO4 --- kopira ostale fajlove koji se nalaze na istoj lokaciji kao i konfig
	novaVerPut = '/home/jukebox/novaVerzija/'
	for fajl in os.listdir(novaVerPut):
		if fajl == 'parametriJuke.txt' or fajl == 'pedja':
			continue
		try:
			shutil.move(novaVerPut + fajl, basePath + fajl)
			os.chmod(basePath + fajl, 0777)
		except Exception as e:
			print("Greska 1023: " + str(e))
	print("Gotovo kopiranje ostalih fajlova u osnovu")
	###DEO4 --- kraj

	###DEO5 --- kopira ostale fajlove koji se nalaze u folderu pedja
	novaVerPut = '/home/jukebox/novaVerzija/pedja/'
	for fajl in os.listdir(novaVerPut):
		if fajl == 'skripte' or fajl == 'jukeB.x86' or fajl == 'jukeB_Data':
			continue
		try:
			shutil.move(novaVerPut + fajl, basePath + 'pedja/' + fajl)
			os.chmod(basePath + 'pedja/' + fajl, 0777)
		except Exception as e:
			print("Greska 1024: " + str(e))
	print("Gotovo kopiranje ostalih fajlova u folder pedja")
	###DEO5 --- kraj

