﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.Threading.Tasks;
using Commons;

namespace KlijentskiDLL
{
    [Export(typeof(IWorkerRole))]
    public class Worker : IWorkerRole {
        public void Start(string containerId) {
            Console.WriteLine("OVO je primer za zahtev 5");
            Console.WriteLine("Pokrenuce se samo ako ima 5 instanci kontejnera");
            Console.WriteLine("Pozvan je start " + containerId);
        }

        public void Stop() {
            Console.WriteLine("POZ!");
            Console.WriteLine("Pozvan je stooop");
        }
    }
}
