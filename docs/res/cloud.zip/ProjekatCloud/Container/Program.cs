﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace Container {
    class Program {
        static int ContainerPort = -1;

        static ServiceHost host = null;

        public static int Port {
            get { return ContainerPort; }
        }

        static void Main(string[] args) {
            if (args.Length > 0) {
                try {
                    ContainerPort = Int32.Parse(args[0]);
                } catch (Exception e) {
                    Greska("Port kontejnera mora biti broj (" + e.ToString() + ")");
                }
            } else {
                Greska("Port kontejnera nije postavljen");
            }

            Console.WriteLine("Moj port je " + ContainerPort);
            try {
                StartService(ContainerPort);
                Console.ReadKey();
                StopService();
            } catch (AddressAlreadyInUseException) {
                Environment.Exit(0);
            } catch (Exception e) {
                Greska(e.ToString());
            }
        }

        ~Program() {
            StopService();
        }

        static void Greska(string poruka) {
            Console.WriteLine(poruka);
            Console.ReadKey();
        }

        static void StartService(int port) {
            if (port > 0) {
                host = new ServiceHost(typeof(ContainerProvider));
                host.AddServiceEndpoint(typeof(Commons.IContainer), new NetTcpBinding(), new Uri("net.tcp://localhost:" + port + "/Kontejner"));
                host.Open();
                Console.WriteLine("Servis pokrenut");
            } else {
                Greska("Servis nije pokrenut, port nije ispravan [" + port + "]");
            }
        }

        static void StopService() {
            if (host != null) {
                host.Close();
                Console.WriteLine("Servis ugasen");
            } else {
                Console.WriteLine("Host je null");
            }
        }
    }
}
