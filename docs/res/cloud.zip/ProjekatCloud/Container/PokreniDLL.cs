﻿using Commons;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Container {
    public class PokreniDLL {

        [ImportMany]
        private IEnumerable<Lazy<IWorkerRole>> PluginProksi { get; set; }

        private CompositionContainer composCont = null;
        private AggregateCatalog aggCatalog = null;

        public void Izvrsi() {
            foreach (Lazy<IWorkerRole> jedanProksi in PluginProksi) {
                jedanProksi.Value.Start(Program.Port.ToString());
                jedanProksi.Value.Stop();
            }
        }

        public void OslobodiDLL() {
            /*if (this.composCont != null) {
                composCont.Dispose();
            }

            if (this.aggCatalog != null) {
                foreach (DirectoryCatalog dc in aggCatalog.Catalogs) {
                    dc.Dispose();
                }
                aggCatalog.Dispose();
            }*/

            new Task(() => {
                Thread.Sleep(1300);
                Environment.Exit(0);
            }).Start();
        }

        public void Ucitaj(string nazivDLLa) {
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new DirectoryCatalog(@"..\..\..\DLLs\p" + Program.Port + "\\" + nazivDLLa.Split('.')[0] + "\\", nazivDLLa));

            var container = new CompositionContainer(catalog);
            container.ComposeParts(this);

            this.composCont = container;
            this.aggCatalog = catalog;
        }
    }
}
