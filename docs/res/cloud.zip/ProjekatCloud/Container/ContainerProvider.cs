﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Commons;

namespace Container {
    public class ContainerProvider : IContainer {
        public bool IsAlive() {
            //Console.WriteLine("javih se");
            return true;
        }

        public string Load(string assemblyName) {
            Console.WriteLine("******************************************");
            Console.WriteLine("Ucitavam: " + assemblyName);
            try {
                PokreniDLL pdll = new PokreniDLL();
                pdll.Ucitaj(assemblyName);
                pdll.Izvrsi();
                pdll.OslobodiDLL();
                return "OK";
            } catch (Exception e) {
                Console.WriteLine("Greska prilikom ucitavanja DLLa: " + e.ToString());
                return "FAIL";
            }
        }
    }
}
