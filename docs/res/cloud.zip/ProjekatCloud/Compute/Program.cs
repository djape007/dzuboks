﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Commons;
using System.Threading;

namespace Compute {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Pokrecem " + Podesavanja.brojKontejnera + " kontejnera");
            for (int i = 0; i < Podesavanja.brojKontejnera; i++) {
                try {
                    IContainer ic = NapraviVezuKaKontejneru(Podesavanja.dostupniPortovi[i]);
                    ic.IsAlive();
                    Podaci.dostupniProksi.Add(new Tuple<IContainer, int>(ic, Podesavanja.dostupniPortovi[i]));
                    Console.WriteLine("Povezao sam se na vec postojeci kontejner na portu " + Podesavanja.dostupniPortovi[i]);
                } catch {
                    PokreniKontejner(Podesavanja.dostupniPortovi[i]);
                    Podaci.dostupniProksi.Add(new Tuple<IContainer, int>(NapraviVezuKaKontejneru(Podesavanja.dostupniPortovi[i]), Podesavanja.dostupniPortovi[i]));
                }
            }

            PokreniNadgledanjeKontejnera(Podaci.dostupniProksi);
            FolderMonitor FM = new FolderMonitor(Podesavanja.PutanjaKaZahtevima);

            Console.ReadKey();

        }

        public static void PokreniKontejner(int port) {
            Process.Start(Podesavanja.PutanjaKontejnerExe + Podesavanja.KontejnerExeNaziv, port.ToString());
            Console.WriteLine("Pokrenut kontejner na portu " + port);
        }

        public static IContainer NapraviVezuKaKontejneru(int port) {
            ChannelFactory<IContainer> fabrikaKanala = new ChannelFactory<IContainer>(new NetTcpBinding(), new EndpointAddress("net.tcp://localhost:" + port + "/Kontejner"));
            return fabrikaKanala.CreateChannel();
        }

        public static void PokreniNadgledanjeKontejnera(List<Tuple<IContainer, int>> zaNadgledanje) {
            ContainerMonitor CM = new ContainerMonitor(zaNadgledanje);
            new Thread(CM.StartMonitoring).Start();
        }
    }

    public static class Podesavanja {
        public static readonly string PutanjaKontejnerExe = @"..\..\..\Container\bin\Debug\";
        public static readonly string KontejnerExeNaziv = "Container.exe";
        public static readonly string PutanjaKaZahtevima = @"..\..\..\zahtevi\";
        public static readonly string DLLsLokacija = @"..\..\..\DLLs\";

        public static readonly int brojKontejnera = 4;
        public static readonly int[] dostupniPortovi = { 10010, 10020, 10031, 10032, 10033, 10034, 10035, 10040, 10050};
    }

    public static class Podaci {
        public static List<Tuple<IContainer, int>> dostupniProksi = new List<Tuple<IContainer,int>>();
    }
}
