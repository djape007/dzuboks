﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Compute {
    public class ObradaZahteva {
        public static void ObradiZahtev(string nazivXMLfajla, int brInstanci) {
            Console.WriteLine("Obradjujem zahtev " + nazivXMLfajla + " [" + brInstanci + "]");
            string nazivDLLa = nazivXMLfajla.Replace(".xml", ".dll");
            if (brInstanci <= Podesavanja.brojKontejnera) {
                for (int i = 0; i < brInstanci; i++) {
                    int port = Podaci.dostupniProksi[i].Item2;

                    KopirajDLLove(nazivDLLa, Podesavanja.DLLsLokacija, port);
                    string odg = Podaci.dostupniProksi[i].Item1.Load(nazivDLLa);

                    if (odg == null || !odg.Equals("OK")) {
                        Console.WriteLine("Doslo je do greske u kontejneru na portu " + port);
                    }
                }
            } else {
                Console.WriteLine("Broj instanci prevelik, zahtev nije prosledjen");
            }
            
            ObrisiZahtev(nazivDLLa);
            
        }

        public static void KopirajDLLove(string nazivDll, string destinacija, int port) {
            Directory.CreateDirectory(destinacija + "p" + port + "\\" + nazivDll.Split('.')[0]);
            try {
                File.Copy(Podesavanja.PutanjaKaZahtevima + nazivDll, destinacija + "p" + port + "\\" + nazivDll.Split('.')[0] + "\\" + nazivDll, true);
            } catch (Exception e) {
                Console.WriteLine("Greska prilikom kopiranja dll-a:" + e.ToString());
            }
        }

        public static void ObrisiZahtev(string nazivDll) {
            try {
                File.Delete(Podesavanja.PutanjaKaZahtevima + nazivDll);
            } catch (Exception e) {
                Console.WriteLine("Greska brisanje zahteva dll: " + e.ToString());
            }
            try {
                File.Delete(Podesavanja.PutanjaKaZahtevima + nazivDll.Replace(".dll", ".xml"));
            } catch (Exception e) {
                Console.WriteLine("Greska brisanje zahteva xml: " + e.ToString());
            }
        }
    }
}
