﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using System.Threading;

namespace Compute {
    public class FolderMonitor {
        FileSystemWatcher fsw = null;
        string prethodniFullPath = "";

        public FolderMonitor(string putanja) {
            try {
                fsw = new FileSystemWatcher(putanja);
                fsw.NotifyFilter = NotifyFilters.LastWrite;
                fsw.Filter = "*.xml";
                fsw.EnableRaisingEvents = true;
                fsw.Changed += Fsw_Changed;
            } catch (Exception e) {
                Console.WriteLine("Greska FolderMonitor: " + e.ToString());
                fsw = null;
            }
        }

        private void Fsw_Changed(object sender, FileSystemEventArgs e) {
            //Console.WriteLine("\t" + e.FullPath);
            if (!e.FullPath.Equals(prethodniFullPath)) {
                prethodniFullPath = e.FullPath;
                ProcitajSaZadrskom(e.FullPath, e.Name);
            }
        }

        private void ProcitajSaZadrskom(string putanja, string nazivFajla, int brPokusaja = 10) {
            new Task(() => {
                while (brPokusaja > 0) {
                    Thread.Sleep(20);
                    try {
                        ProcitajBrojInstanci(putanja, nazivFajla);
                        brPokusaja = -1;
                    } catch {
                        brPokusaja--;
                    }
                }
            }).Start();
        }

        private void ProcitajBrojInstanci (string putanja, string nazivXMLFajla) {
            int instance = 0;
            XmlReader xmlr = XmlReader.Create(putanja);
            while (xmlr.Read()) {
                switch (xmlr.NodeType) {
                    case XmlNodeType.Text:
                        Int32.TryParse(xmlr.Value, out instance);
                    break;
                }
            }
            xmlr.Close();
            ObradaZahteva.ObradiZahtev(nazivXMLFajla, instance);
            prethodniFullPath = "";
        }
    }
}
