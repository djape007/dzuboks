﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Commons;
using System.Threading;

namespace Compute {
    public class ContainerMonitor {
        List<Tuple<IContainer, int>> zaPracenje = null;
        List<int> indeksiFailovalih = new List<int>();

        public ContainerMonitor(List<Tuple<IContainer,int>> toMonitor) {
            zaPracenje = toMonitor;
        }

        public void StartMonitoring() {
            if (zaPracenje.Count > 0) {
                while (true) {
                    SviKontejneriZivi();
                    DaLiJeNekoPao();
                    Thread.Sleep(1000);
                }
            } else {
                Console.WriteLine("Lista za pracenje je prazna!");
            }
        }

        public void SviKontejneriZivi() {
            for (int i = 0; i < zaPracenje.Count; i++) {
                Tuple<IContainer, int> tmpTuple = zaPracenje[i];

                bool odg = false;
                try {
                    odg = tmpTuple.Item1.IsAlive();
                } catch {
                    odg = false;
                }

                if (odg != true) {
                    indeksiFailovalih.Add(i);
                }
            }
        }

        public void DaLiJeNekoPao() {
            if (indeksiFailovalih.Count > 0) {
                foreach (int indeks in indeksiFailovalih) {
                    int port = zaPracenje[indeks].Item2;
                    Console.WriteLine("Pao " + port + " pokusacu da ga pokrenem");
                    //proksi koje je failovo na X portu, se menja novim proksijem koji bi trebao da je povezan
                    zaPracenje.RemoveAt(indeks);
                    zaPracenje.Add(new Tuple<IContainer, int>(PonovoPokreniIPoveziSe(port), port));
                }
                indeksiFailovalih.Clear();
            } else {
                //Console.WriteLine("Svi su upaljeni");
            }
        }

        public IContainer PonovoPokreniIPoveziSe(int port) {
            Program.PokreniKontejner(port);
            return Program.NapraviVezuKaKontejneru(port);
        }
    }
}
