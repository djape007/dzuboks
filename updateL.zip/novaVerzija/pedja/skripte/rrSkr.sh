#!/bin/bash

sleep 1.5

cd /home/jukebox/pedja
chmod +x jukeB.x86
./jukeB.x86 &

exit 0