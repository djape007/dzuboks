#!/bin/bash

cd /home/jukebox/pedja/skripte

echo ""
echo ""
echo ""

python /home/jukebox/pedja/skripte/update_main.py

echo ""
echo ""
echo ""

./pokreniUnity.sh

exit 0
