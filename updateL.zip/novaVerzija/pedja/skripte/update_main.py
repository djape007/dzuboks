# -*- coding: utf-8 -*-

import urllib2 as url2
import auto_update as AU
import sys
from Tkinter import *
from time import sleep

#GRAFIKA
root = Tk()
var = StringVar()
varTitle = StringVar()
varTitle.set('Autoupdater')
var.set('Proveravam da li ima novi update za džuboks...')

ws = root.winfo_screenwidth() # width of the screen
hs = root.winfo_screenheight() # height of the screen

w = ws
h = hs

x = (ws/2) - (w/2)
y = (hs/2) - (h/2)

root.geometry('%dx%d+%d+%d' % (w, h, x, y))
root.configure(background='black')
root.wm_title("DžUBOKS AUTOUPDATE")
l = Label(root, textvariable = var, font=(None, 25), fg="white", bg="black")
lTitle = Label(root, textvariable = varTitle, font=(None, 23), fg="white", bg="black")
lTitle.pack()

l.pack(expand=YES, fill=BOTH)
l.pack()

root.update_idletasks()

#KRAJ GRAFIKE, posle ima na jos par mesta
autoUpdate = True

if autoUpdate:
	linkVfajl = 'https://github.com/djape007/predragBabicJukeB/raw/master/verzija.txt'

	#print("Proveravam da li ima nova verzija....")
	try:
		fajl = url2.urlopen(linkVfajl)
		tekst = fajl.read()
	except Exception as e:
		print("Greska update_main: " + str(e))
		sys.exit(0)

	brNoveVerzije = float(tekst[1:])
	
	try:
		fff = open('/home/jukebox/pedja/v', "r")
	
		for red in fff:
			tekst = red
			break
	
		fff.close()
		brTrenutneBerzije = float(tekst[1:])
	except:
		brTrenutneBerzije = -1

	if brNoveVerzije > brTrenutneBerzije:
		#print("Dostupna je nova verzija: " + str(brNoveVerzije))
		var.set("Dostupna je nova verzija! (" + str(brNoveVerzije) + ")")
		root.update_idletasks()
		sleep(1)
		var.set("Počinje updateovanje...\nSačekaj")
		root.update_idletasks()
		sleep(2)
		#print("###POCINJE UPDATEOVANJE###")
		AU.main(root, var)
		fff = open('/home/jukebox/pedja/v', "w")
		fff.write("v" + str(brNoveVerzije))
		fff.close()
		var.set("Updateovanje je završeno\nPokrećem glavni program")
		root.update_idletasks()
		sleep(2)
	else:
		#print("Koristiš najnoviju verziju")
		var.set("Koristiš najnoviju verziju! (" + str(brTrenutneBerzije) + ")\nPokrećem glavni program")
		root.update_idletasks()
		sleep(4)
else:
	#print("Autoupdate je iskljucen")
	var.set("Automatsko updateovanje je isključeno!\nPokrećem glavni program")
	root.update_idletasks()
	sleep(4)

sys.exit(0)
