#!/bin/bash

mkdir /home/jukebox/pedja/cache ;
rm /home/jukebox/pedja/cache/*

sleep 0.5

cd /home/jukebox/pedja/skripte

./updateYTD.sh &

sleep 0.1

./pingGoogle.sh &

cd /home/jukebox/pedja/skripte

chmod +x pokreniServer.sh

./pokreniServer.sh &

sleep 3

cd /home/jukebox/pedja

chmod +x jukeB.x86

./jukeB.x86 &

exit 0
